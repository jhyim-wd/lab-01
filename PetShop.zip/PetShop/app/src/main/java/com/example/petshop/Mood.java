package com.example.petshop;

import java.util.Date;

public abstract class Mood {
    public Date moodDate;
    public abstract String express();

    // constructors
    public Mood() {
        Date moodDate = new Date();
    }

    public Mood(Date moodDate) {
        this.moodDate = moodDate;
    }

    // getters and setters
    public Date getMoodDate() {
        return moodDate;
    }

    public void setMoodDate(Date moodDate) {
        this.moodDate = moodDate;
    }
}

class Happy extends Mood {
    public Happy(Date moodDate) {
        super(moodDate);
    }

    @Override
    public String express() {
        return "Happy";
    }
}

class Sad extends Mood {
    public Sad(Date moodDate) {
        super(moodDate);
    }

    @Override
    public String express() {
        return "Sad";
    }
}