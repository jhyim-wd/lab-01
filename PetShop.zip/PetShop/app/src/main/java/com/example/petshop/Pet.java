package com.example.petshop;

import java.util.Date;

// superclass
public abstract class Pet {
    // attributes
    public String name;
    public Date birthdate;

    // constructors

    public Pet(String name) {
        this.name = name;
        Date birthdate = new Date();
    }

    public Pet(String name, Date birthdate) {
        this.name = name;
        this.birthdate = birthdate;
    }

    // getters and setters

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(Date birthdate) {
        this.birthdate = birthdate;
    }

    // speaking
    public abstract String speak();
}

// subclasses
class Cat extends Pet implements Pettable {
    // constructors
    public Cat(String name) {
        super(name);
    }

    public Cat(String name, Date birthdate) {
        super(name, birthdate);
    }

    // method overriding
    @Override
    public String speak() {
        return "meow";
    }

    public Void pet() {
        return null;
    }
}

class Dog extends Pet implements Pettable {
    public Dog(String name) {
        super(name);
    }
    public Dog(String name, Date birthdate) {
        super(name, birthdate);
    }
    @Override
    public String speak() {
        return "bark";
    }

    public Void pet() {
        return null;
    }
}

class Scorpion extends Pet {
    public Scorpion(String name) {
        super(name);
    }
    public Scorpion(String name, Date birthdate) {
        super(name, birthdate);
    }
    @Override
    public String speak() {
        return "hiss";
    }
}