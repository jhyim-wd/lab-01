package com.example.petshop;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Cat cat = new Cat("Lucy");
    Dog dog = new Dog("Snoopy");
    Scorpion scorpion = new Scorpion("Scorponok");
    ArrayList<Pet> petList = new ArrayList<Pet>();
    ArrayList<Pettable> pettablePets = new ArrayList<Pettable>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        /*
        Author: stinepike https://stackoverflow.com/users/603742/stinepike
        Title: Why isn't ArrayList<>.add() working?
        Answer: https://stackoverflow.com/a/29117701
        Date: 2015-03-18
        License: CC BY-SA 3.0
        */
        petList.add(cat);
        petList.add(dog);
        petList.add(scorpion);

        pettablePets.add(cat);
        pettablePets.add(dog);
        // pettablePets.add(scorpion);
    }
}