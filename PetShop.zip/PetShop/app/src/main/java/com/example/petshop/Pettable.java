package com.example.petshop;

public interface Pettable {
    public Void pet();
}
